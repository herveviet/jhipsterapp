/**
 * Data Access Objects used by WebSocket services.
 */
package com.mycompany.myapp.web.websocket.dto;
