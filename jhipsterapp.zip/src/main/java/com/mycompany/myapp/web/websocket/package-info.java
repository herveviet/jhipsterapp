/**
 * WebSocket services, using Spring Websocket.
 */
package com.mycompany.myapp.web.websocket;
